import "server-only"
import { createClient } from "@supabase/supabase-js"

function getSupabaseServer() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url) throw new Error("NEXT_PUBLIC_SUPABASE_URL is not set")
  if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY is not set")
  return createClient<any>(url, key, { auth: { persistSession: false } })
}

export interface CustomFont {
  id: string
  name: string
  label: string
  description?: string
  file_name: string
  file_url: string
  font_weight: string
  font_style: string
  source: "custom"
  active: boolean
  created_at: string
}

/**
 * Lade alle aktiven custom fonts aus der Datenbank
 */
export async function getCustomFonts(): Promise<CustomFont[]> {
  try {
    const supabase = getSupabaseServer()
    const { data, error } = await supabase
      .from("custom_fonts")
      .select("*")
      .eq("active", true)
      .order("created_at", { ascending: false })

    if (error) throw error
    return (data || []) as CustomFont[]
  } catch (error) {
    console.error("Error fetching custom fonts:", error)
    return []
  }
}

/**
 * Speichere einen hochgeladenen Font in der Datenbank
 */
export async function createCustomFont(
  name: string,
  label: string,
  description: string,
  fileName: string,
  fileUrl: string,
  fontWeight: string = "100 900",
  fontStyle: string = "normal"
): Promise<CustomFont | null> {
  try {
    const supabase = getSupabaseServer()
    const { data, error } = await supabase
      .from("custom_fonts")
      .insert({
        name,
        label,
        description,
        file_name: fileName,
        file_url: fileUrl,
        font_weight: fontWeight,
        font_style: fontStyle,
        source: "custom",
        active: true,
      })
      .select()
      .single()

    if (error) throw error
    return data as CustomFont
  } catch (error) {
    console.error("Error creating custom font:", error)
    throw error
  }
}

/**
 * Lösche einen custom font
 */
export async function deleteCustomFont(fontId: string): Promise<void> {
  try {
    const supabase = getSupabaseServer()
    const { error } = await supabase
      .from("custom_fonts")
      .update({ active: false })
      .eq("id", fontId)

    if (error) throw error
  } catch (error) {
    console.error("Error deleting custom font:", error)
    throw error
  }
}

/**
 * Lade Font-Datei zu Supabase Storage hoch
 */
export async function uploadFontFile(
  file: File
): Promise<{ path: string; url: string }> {
  try {
    const supabase = getSupabaseServer()
    const fileName = `${Date.now()}-${file.name}`

    const { error } = await supabase.storage
      .from("fonts")
      .upload(fileName, file, {
        cacheControl: "31536000", // 1 Jahr Cache
        upsert: false,
      })

    if (error) throw error

    // Öffentliche URL abrufen
    const { data } = supabase.storage.from("fonts").getPublicUrl(fileName)

    return {
      path: fileName,
      url: data.publicUrl,
    }
  } catch (error) {
    console.error("Error uploading font file:", error)
    throw error
  }
}

/**
 * Lösche Font-Datei aus Supabase Storage
 */
export async function deleteFontFile(fileName: string): Promise<void> {
  try {
    const supabase = getSupabaseServer()
    const { error } = await supabase.storage
      .from("fonts")
      .remove([fileName])

    if (error) throw error
  } catch (error) {
    console.error("Error deleting font file:", error)
    throw error
  }
}
