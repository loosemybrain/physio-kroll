import { NextRequest, NextResponse } from "next/server"
import { createSupabaseServerClient } from "@/lib/supabase/server"
import { getCustomFonts } from "@/lib/fonts/storage.custom"

export async function GET(request: NextRequest) {
  try {
    // Authentifizierung prüfen
    const supabase = await createSupabaseServerClient()
    const { data: userData } = await supabase.auth.getUser()

    if (!userData.user) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const fonts = await getCustomFonts()

    return NextResponse.json({
      success: true,
      fonts,
    })
  } catch (error) {
    console.error("Error fetching custom fonts:", error)
    return NextResponse.json(
      { error: "Fehler beim Abrufen der Fonts" },
      { status: 500 }
    )
  }
}
