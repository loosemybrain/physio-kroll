import { NextRequest, NextResponse } from "next/server"
import { createSupabaseServerClient } from "@/lib/supabase/server"
import { uploadFontFile, createCustomFont } from "@/lib/fonts/storage.custom"

export const config = {
  api: {
    bodyParser: {
      sizeLimit: "50mb",
    },
  },
}

export async function POST(request: NextRequest) {
  try {
    // Authentifizierung prüfen
    const supabase = await createSupabaseServerClient()
    const { data: userData } = await supabase.auth.getUser()

    if (!userData.user) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    // FormData parsen
    const formData = await request.formData()
    const file = formData.get("file") as File
    const name = formData.get("name") as string
    const label = formData.get("label") as string
    const description = formData.get("description") as string
    const fontWeight = (formData.get("fontWeight") as string) || "100 900"
    const fontStyle = (formData.get("fontStyle") as string) || "normal"

    // Validierung
    if (!file) {
      return NextResponse.json(
        { error: "Keine Datei hochgeladen" },
        { status: 400 }
      )
    }

    if (!name || !label) {
      return NextResponse.json(
        { error: "Name und Label sind erforderlich" },
        { status: 400 }
      )
    }

    // Dateiformat prüfen
    if (!file.name.endsWith(".woff2")) {
      return NextResponse.json(
        { error: "Nur .woff2 Dateien sind erlaubt" },
        { status: 400 }
      )
    }

    // Dateigröße prüfen (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: "Datei zu groß (max 10MB)" },
        { status: 400 }
      )
    }

    // Datei hochladen
    const { path, url } = await uploadFontFile(file)

    // Font in Datenbank speichern
    const customFont = await createCustomFont(
      name,
      label,
      description,
      path,
      url,
      fontWeight,
      fontStyle
    )

    return NextResponse.json({
      success: true,
      font: customFont,
    })
  } catch (error) {
    console.error("Font upload error:", error)
    return NextResponse.json(
      { error: "Font-Upload fehlgeschlagen" },
      { status: 500 }
    )
  }
}
