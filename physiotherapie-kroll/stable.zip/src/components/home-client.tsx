"use client"

import { HeroSection } from "@/components/blocks/hero-section"

export function HomeClient() {
  return (
    <>
      {/* Hero Section */}
      <HeroSection showBrandToggle={true} />
    </>
  )
}
