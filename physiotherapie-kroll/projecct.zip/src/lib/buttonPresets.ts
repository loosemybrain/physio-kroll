/**
 * Button design presets using only existing classes from globals.css:
 * animate-fade-in-up, animate-slide-in-left, animate-fade-in, animate-scale-in
 * hover-lift, hover-lift-md
 */

export type ButtonPresetVariant = "default" | "secondary" | "outline" | "ghost" | "link"

export interface ButtonPreset {
  id: string
  label: string
  variant: ButtonPresetVariant
  className: string
}

export const BUTTON_PRESETS: ButtonPreset[] = [
  {
    id: "primaryLiftFadeUp",
    label: "Primary Lift Fade Up",
    variant: "default",
    className:
      "hover-lift-md animate-fade-in-up focus-visible:ring-2 focus-visible:ring-primary/30 shadow-sm hover:shadow-lg active:shadow-md active:opacity-95",
  },
  {
    id: "outlineSweepSlideLeft",
    label: "Outline Sweep Slide Left",
    variant: "outline",
    className:
      "relative overflow-hidden animate-slide-in-left hover:border-primary/60 before:absolute before:inset-0 before:-translate-x-full before:bg-primary/10 before:transition-transform before:duration-300 before:ease-out hover:before:translate-x-0 focus-visible:ring-2 focus-visible:ring-primary/20",
  },
  {
    id: "ghostSoftFade",
    label: "Ghost Soft Fade",
    variant: "ghost",
    className:
      "animate-fade-in hover:bg-primary/10 focus-visible:ring-2 focus-visible:ring-primary/20 active:opacity-90",
  },
  {
    id: "pillScaleIn",
    label: "Pill Scale In",
    variant: "secondary",
    className:
      "rounded-full animate-scale-in hover-lift shadow-sm hover:shadow-lg focus-visible:ring-2 focus-visible:ring-primary/25",
  },
  // --- New visually enhanced button presets below ---
  {
    id: "glass-primary",
    label: "Glass Primary",
    variant: "default",
    className:
      "bg-primary/80 text-primary-foreground backdrop-blur-md border border-white/20 shadow-[0_4px_24px_-6px_rgba(0,0,0,0.25)] hover:bg-primary hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.35)] transition-all duration-300 ease-out",
  },
  {
    id: "gradient-lux",
    label: "Gradient Lux",
    variant: "default",
    className:
      "bg-gradient-to-r from-primary via-accent to-primary text-primary-foreground shadow-lg hover:brightness-110 hover:shadow-xl transition-all duration-300",
  },
  {
    id: "soft-elevated",
    label: "Soft Elevated",
    variant: "default",
    className:
      "bg-card text-foreground border border-border/40 shadow-[0_2px_12px_-4px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 hover:shadow-[0_8px_24px_-6px_rgba(0,0,0,0.15)] transition-all duration-300",
  },
  {
    id: "glow-accent",
    label: "Glow Accent",
    variant: "default",
    className:
      "bg-primary text-primary-foreground shadow-[0_0_0_1px_var(--primary),0_8px_32px_-8px_rgba(0,0,0,0.3)] hover:shadow-[0_0_0_1px_var(--primary),0_16px_48px_-12px_rgba(0,0,0,0.4)] transition-all duration-300",
  },
]

const presetById = new Map(BUTTON_PRESETS.map((p) => [p.id, p]))

export function getButtonPreset(presetId: string | undefined): ButtonPreset | undefined {
  if (!presetId) return undefined
  return presetById.get(presetId)
}

/**
 * Resolve variant and className for a button: per-button overrides take precedence over preset.
 */
export function resolveButtonPresetStyles(
  presetId: string | undefined,
  buttonVariant?: ButtonPresetVariant,
  buttonClassName?: string
): { variant: ButtonPresetVariant; className: string } {
  const preset = getButtonPreset(presetId)
  const variant = (buttonVariant ?? preset?.variant ?? "default") as ButtonPresetVariant
  const presetClass = preset?.className ?? ""
  const className = [presetClass, buttonClassName].filter(Boolean).join(" ")
  return { variant, className }
}
