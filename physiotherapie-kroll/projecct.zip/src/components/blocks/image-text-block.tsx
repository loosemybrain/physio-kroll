"use client"

import * as React from "react"
import Image from "next/image"
import { motion, type Variants } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { CardSurface } from "@/components/ui/card"
import { useElementShadowStyle } from "@/lib/shadow"
import { resolveButtonPresetStyles } from "@/lib/buttonPresets"
import type { ImageTextStyle } from "@/types/cms"

interface ImageTextBlockProps {
  section?: unknown
  typography?: unknown

  // Content
  eyebrow?: string
  headline?: string
  content: string

  // Image
  imageUrl: string
  imageAlt: string
  imagePosition?: "left" | "right"

  // CTA
  ctaText?: string
  ctaHref?: string

  // Styling
  background?: "none" | "muted" | "gradient"
  backgroundColor?: string
  eyebrowColor?: string
  headlineColor?: string
  contentColor?: string
  ctaTextColor?: string
  ctaBgColor?: string
  ctaHoverBgColor?: string
  ctaBorderColor?: string

  // Design System
  designPreset?: string
  style?: ImageTextStyle

  // CMS/Inline Edit Props
  editable?: boolean
  blockId?: string
  onEditField?: (blockId: string, fieldPath: string, anchorRect?: DOMRect) => void
  
  // Shadow/Element Props
  elements?: Record<string, any>
  onElementClick?: (blockId: string, elementId: string) => void
  selectedElementId?: string | null

  buttonPreset?: string
}

// ============================================================================
// Constants
// ============================================================================

const maxWidthClasses: Record<string, string> = {
  md: "max-w-3xl",
  lg: "max-w-5xl",
  xl: "max-w-7xl",
}

const verticalAlignClasses: Record<string, string> = {
  top: "items-start",
  center: "items-center",
}

const textAlignClasses: Record<string, string> = {
  left: "text-left",
  center: "text-center",
}

const aspectRatioClasses: Record<string, string> = {
  "4/3": "aspect-4/3",
  "16/9": "aspect-video",
  "1/1": "aspect-square",
  "3/2": "aspect-[3/2]",
}

// ============================================================================
// Animation Variants
// ============================================================================

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
}

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.25, 0.1, 0.25, 1] },
  },
}

const imageVariants: Variants = {
  hidden: { opacity: 0, scale: 0.97 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, ease: [0.25, 0.1, 0.25, 1] },
  },
}

// ============================================================================
// Design Presets
// ============================================================================

const designPresets: Record<string, { style: ImageTextStyle; background?: "none" | "muted" | "gradient"; imagePosition?: "left" | "right" }> = {
  standard: {
    style: { variant: "default", verticalAlign: "center", textAlign: "left", maxWidth: "lg" },
    background: "none",
    imagePosition: "left",
  },
  soft: {
    style: { variant: "soft", verticalAlign: "center", textAlign: "left", maxWidth: "lg" },
    background: "muted",
    imagePosition: "left",
  },
  softCentered: {
    style: { variant: "soft", verticalAlign: "center", textAlign: "center", maxWidth: "lg" },
    background: "muted",
    imagePosition: "left",
  },
  imageRight: {
    style: { variant: "default", verticalAlign: "center", textAlign: "left", maxWidth: "lg" },
    background: "none",
    imagePosition: "right",
  },
  imageRightCentered: {
    style: { variant: "default", verticalAlign: "center", textAlign: "center", maxWidth: "lg" },
    background: "none",
    imagePosition: "right",
  },
  topAligned: {
    style: { variant: "default", verticalAlign: "top", textAlign: "left", maxWidth: "lg" },
    background: "none",
    imagePosition: "left",
  },
}

// ============================================================================
// Helpers
// ============================================================================

function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches
}

function getElementConfig(elementId: string, canonical: string, elements: Record<string, any> | undefined) {
  return elements?.[canonical] ?? elements?.[elementId]
}

export function ImageTextBlock(props: ImageTextBlockProps) {
  const {
    eyebrow,
    headline,
    content,
    imageUrl,
    imageAlt,
    imagePosition: imagePosOverride,
    ctaText,
    ctaHref,
    background: bgOverride,
    backgroundColor,
    eyebrowColor,
    headlineColor,
    contentColor,
    ctaTextColor,
    ctaBgColor,
    ctaHoverBgColor,
    ctaBorderColor,
    designPreset,
    style: styleOverride,
    editable = false,
    blockId,
    onEditField,
    elements,
    onElementClick,
    selectedElementId,
    buttonPreset,
  } = props

  const ctaPreset = resolveButtonPresetStyles(buttonPreset, undefined, undefined)

  // Resolve effective design from preset or overrides
  const preset = (designPreset && designPresets[designPreset]) || designPresets.standard
  const effectiveStyle: ImageTextStyle = styleOverride || preset.style
  const effectiveBackground = bgOverride || preset.background || "none"
  const effectiveImagePosition = imagePosOverride || preset.imagePosition || "left"

  // Element shadows with fallback (canonical key OR legacy key)
  const surfaceShadow = useElementShadowStyle({
    elementId: "imageText.surface",
    elementConfig: getElementConfig("imageText.surface", "imageText.surface", elements),
  })
  const imageShadow = useElementShadowStyle({
    elementId: "imageText.image",
    elementConfig: getElementConfig("imageText.image", "image", elements),
  })
  const eyebrowShadow = useElementShadowStyle({
    elementId: "imageText.eyebrow",
    elementConfig: getElementConfig("imageText.eyebrow", "eyebrow", elements),
  })
  const headlineShadow = useElementShadowStyle({
    elementId: "imageText.headline",
    elementConfig: getElementConfig("imageText.headline", "headline", elements),
  })
  const contentShadow = useElementShadowStyle({
    elementId: "imageText.content",
    elementConfig: getElementConfig("imageText.content", "content", elements),
  })
  const ctaShadow = useElementShadowStyle({
    elementId: "imageText.cta",
    elementConfig: getElementConfig("imageText.cta", "cta", elements),
  })

  const canInlineEdit = Boolean(editable && blockId && onEditField)
  const isImageLeft = effectiveImagePosition === "left"
  const [ctaHovered, setCtaHovered] = React.useState(false)
  const prefersNoMotion = prefersReducedMotion()

  const motionProps = prefersNoMotion
    ? {}
    : {
        initial: "hidden",
        whileInView: "visible",
        viewport: { once: true, margin: "-60px" },
        variants: containerVariants,
      }

  const isSoft = effectiveStyle.variant === "soft"
  const bgClass =
    effectiveBackground === "muted"
      ? "bg-muted/30"
      : effectiveBackground === "gradient"
        ? "bg-gradient-to-b from-muted/20 to-background"
        : ""

  const sectionStyle: React.CSSProperties | undefined = backgroundColor
    ? { backgroundColor }
    : undefined

  const ctaStyle: React.CSSProperties = {
    color: ctaTextColor || undefined,
    backgroundColor: ctaBgColor
      ? ctaHovered && ctaHoverBgColor
        ? ctaHoverBgColor
        : ctaBgColor
      : undefined,
    borderColor: ctaBorderColor || undefined,
  }

  function handleInlineEdit(e: React.MouseEvent, fieldPath: string, elementId?: string) {
    if (!canInlineEdit) return
    if (elementId && onElementClick) {
      onElementClick(blockId || "", elementId)
    }
    e.preventDefault()
    e.stopPropagation()
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    onEditField?.(blockId || "", fieldPath, rect)
  }

  const verticalAlignClass = verticalAlignClasses[effectiveStyle.verticalAlign || "center"] || "items-center"
  const textAlignClass = textAlignClasses[effectiveStyle.textAlign || "left"] || "text-left"
  const maxWidthClass = maxWidthClasses[effectiveStyle.maxWidth || "lg"] || maxWidthClasses.lg
  const aspectRatioClass = aspectRatioClasses[effectiveStyle.imageAspectRatio || "4/3"] || aspectRatioClasses["4/3"]

  return (
    <CardSurface
      data-element-id="imageText.surface"
      style={{
        ...(surfaceShadow as any),
        backgroundColor: backgroundColor || undefined,
      }}
      className={cn(
        "w-full",
        bgClass
      )}
      onClick={(e) => {
        if ((e.target as HTMLElement).closest("[data-element-id]") === e.currentTarget && onElementClick) {
          onElementClick(blockId || "", "imageText.surface")
        }
      }}
    >
      <motion.div
        {...motionProps}
        className={cn(
          "mx-auto px-4 py-16 md:py-24",
          maxWidthClass
        )}
      >
        <div
          className={cn(
            "grid gap-10 md:grid-cols-2 md:gap-12 lg:gap-20",
            verticalAlignClass
          )}
        >
          {/* Image Column */}
          <motion.figure
            variants={prefersNoMotion ? undefined : imageVariants}
            className={cn(
              "relative overflow-hidden rounded-2xl",
              isImageLeft ? "order-1 md:order-1" : "order-2 md:order-2"
            )}
            data-element-id="imageText.image"
            style={imageShadow}
            onClick={(e) => {
              if (!editable) return
              onElementClick?.(blockId || "", "imageText.image")
            }}
          >
            <div className={cn("relative w-full", aspectRatioClass)}>
              <Image
                src={imageUrl || "/placeholder.svg"}
                alt={imageAlt ?? headline ?? ""}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
                priority={false}
              />
              {/* Subtle overlay for depth */}
              <div
                className={cn(
                  "absolute inset-0",
                  isSoft
                    ? "bg-linear-to-t from-muted/20 to-transparent"
                    : "bg-linear-to-t from-background/10 to-transparent"
                )}
                aria-hidden="true"
              />
            </div>
          </motion.figure>

          {/* Text Column */}
          <div
            className={cn(
              "flex flex-col justify-center gap-6",
              isImageLeft ? "order-2 md:order-2" : "order-1 md:order-1",
              textAlignClass
            )}
          >
            {/* Eyebrow */}
            {eyebrow && (
              <motion.div variants={prefersNoMotion ? undefined : itemVariants}>
                <span
                  data-element-id="imageText.eyebrow"
                  className={cn(
                    "inline-block text-xs font-medium uppercase tracking-wider text-primary",
                    canInlineEdit && "cursor-pointer rounded px-1 transition-colors hover:bg-primary/10"
                  )}
                  style={eyebrowShadow}
                  onClick={(e) => canInlineEdit && handleInlineEdit(e, "eyebrow", "imageText.eyebrow")}
                  contentEditable={canInlineEdit}
                  suppressContentEditableWarning
                >
                  {eyebrow}
                </span>
              </motion.div>
            )}

            {/* Headline */}
            {headline && (
              <motion.div variants={prefersNoMotion ? undefined : itemVariants}>
                <h2
                  id={blockId ? `${blockId}-headline` : undefined}
                  data-element-id="imageText.headline"
                  className={cn(
                    "text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl",
                    canInlineEdit && "cursor-pointer rounded px-1 transition-colors hover:bg-primary/10"
                  )}
                  style={{
                    ...headlineShadow,
                    ...(headlineColor ? { color: headlineColor } : {}),
                  }}
                  onClick={(e) => canInlineEdit && handleInlineEdit(e, "headline", "imageText.headline")}
                  contentEditable={canInlineEdit}
                  suppressContentEditableWarning
                >
                  {headline}
                </h2>
              </motion.div>
            )}

            {/* Content */}
            <motion.div variants={prefersNoMotion ? undefined : itemVariants}>
              <div
                data-element-id="imageText.content"
                className={cn(
                  "prose prose-neutral dark:prose-invert max-w-none text-pretty text-base leading-relaxed text-muted-foreground md:text-lg md:leading-8",
                  canInlineEdit && "cursor-pointer rounded px-1 transition-colors hover:bg-primary/10"
                )}
                style={{
                  ...contentShadow,
                  ...(contentColor ? { color: contentColor } : {}),
                }}
                onClick={(e) => canInlineEdit && handleInlineEdit(e, "content", "imageText.content")}
                contentEditable={canInlineEdit}
                suppressContentEditableWarning
              >
                {content}
              </div>
            </motion.div>

            {/* CTA */}
            {(ctaText || canInlineEdit) && (
              <motion.div
                variants={prefersNoMotion ? undefined : itemVariants}
                className={cn(
                  "pt-2",
                  effectiveStyle.textAlign === "center" && "flex justify-center"
                )}
              >
                <Button
                  variant={ctaPreset.variant}
                  size="lg"
                  className={cn(
                    ctaPreset.className,
                    "group gap-2 rounded-xl text-base font-semibold transition-all duration-300 hover:-translate-y-0.5"
                  )}
                  asChild={!canInlineEdit && !!ctaHref}
                  onClick={canInlineEdit ? (e) => handleInlineEdit(e, "ctaText", "imageText.cta") : undefined}
                  onMouseEnter={() => setCtaHovered(true)}
                  onMouseLeave={() => setCtaHovered(false)}
                  style={{
                    ...ctaShadow,
                    ...ctaStyle,
                    backgroundColor:
                      ctaHovered && ctaHoverBgColor
                        ? ctaHoverBgColor
                        : ctaBgColor || undefined,
                  }}
                >
                  {!canInlineEdit && ctaHref ? (
                    <a href={ctaHref}>
                      <span
                        data-element-id="imageText.cta"
                        contentEditable={false}
                      >
                        {ctaText || "Button"}
                      </span>
                      <ArrowRight
                        className="size-4 transition-transform duration-300 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </a>
                  ) : (
                    <>
                      <span
                        data-element-id="imageText.cta"
                        contentEditable={canInlineEdit}
                        suppressContentEditableWarning
                      >
                        {ctaText || "CTA"}
                      </span>
                      <ArrowRight
                        className="size-4 transition-transform duration-300 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </>
                  )}
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>
    </CardSurface>
  )
}
