"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { AnimatedBlock } from "@/components/blocks/AnimatedBlock"
import type { BlockSectionProps } from "@/types/cms"
import { useElementShadowStyle } from "@/lib/shadow"
import { resolveButtonPresetStyles } from "@/lib/buttonPresets"
import { mergeTypographyClasses } from "@/lib/typography"

interface CtaBlockProps {
  section?: BlockSectionProps
  typography?: unknown
  headline: string
  subheadline?: string
  primaryCtaText: string
  primaryCtaHref: string
  secondaryCtaText?: string
  secondaryCtaHref?: string
  variant?: "default" | "centered" | "split"
  backgroundColor?: string
  headlineColor?: string
  subheadlineColor?: string
  primaryCtaTextColor?: string
  primaryCtaBgColor?: string
  primaryCtaHoverBgColor?: string
  primaryCtaBorderColor?: string
  primaryCtaBorderRadius?: string
  secondaryCtaTextColor?: string
  secondaryCtaBgColor?: string
  secondaryCtaHoverBgColor?: string
  secondaryCtaBorderColor?: string
  secondaryCtaBorderRadius?: string
  
  // CMS/Inline Edit Props
  editable?: boolean
  blockId?: string
  onEditField?: (blockId: string, fieldPath: string, anchorRect?: DOMRect) => void
  
  // Shadow/Element Props
  elements?: Record<string, any>
  onElementClick?: (blockId: string, elementId: string) => void
  selectedElementId?: string | null

  buttonPreset?: string
}

export function CtaBlock({
  section,
  typography,
  headline,
  subheadline,
  primaryCtaText,
  primaryCtaHref,
  secondaryCtaText,
  secondaryCtaHref,
  variant = "centered",
  backgroundColor,
  headlineColor,
  subheadlineColor,
  primaryCtaTextColor,
  primaryCtaBgColor,
  primaryCtaHoverBgColor,
  primaryCtaBorderColor,
  primaryCtaBorderRadius,
  secondaryCtaTextColor,
  secondaryCtaBgColor,
  secondaryCtaHoverBgColor,
  secondaryCtaBorderColor,
  secondaryCtaBorderRadius,
  
  editable = false,
  blockId,
  onEditField,
  elements,
  onElementClick,
  selectedElementId,
  buttonPreset,
}: CtaBlockProps) {
  const isCentered = variant === "centered"
  const isSplit = variant === "split"
  const [primaryHover, setPrimaryHover] = React.useState(false)
  const [secondaryHover, setSecondaryHover] = React.useState(false)

  const primaryPreset = resolveButtonPresetStyles(buttonPreset, undefined, undefined)
  const secondaryPreset = resolveButtonPresetStyles(buttonPreset, "outline", undefined)

  // Element shadows
  const headlineShadow = useElementShadowStyle({
    elementId: "headline",
    elementConfig: (elements ?? {})["headline"],
  })
  const subheadlineShadow = useElementShadowStyle({
    elementId: "subheadline",
    elementConfig: (elements ?? {})["subheadline"],
  })
  const primaryCtaShadow = useElementShadowStyle({
    elementId: "primaryCta",
    elementConfig: (elements ?? {})["primaryCta"],
  })
  const secondaryCtaShadow = useElementShadowStyle({
    elementId: "secondaryCta",
    elementConfig: (elements ?? {})["secondaryCta"],
  })
  
  const canInlineEdit = Boolean(editable && blockId && onEditField)
  
  // FIELD PATHS
  const FP = {
    headline: "headline",
    subheadline: "subheadline",
    primaryCtaText: "primaryCtaText",
    primaryCtaHref: "primaryCtaHref",
    secondaryCtaText: "secondaryCtaText",
    secondaryCtaHref: "secondaryCtaHref",
  } as const
  
  function handleInlineEdit(e: React.SyntheticEvent, fieldPath: string, elementId?: string) {
    if (!canInlineEdit || !blockId || !onEditField) return
    
    if (elementId && onElementClick) {
      onElementClick(blockId, elementId)
    }
    
    e.preventDefault()
    e.stopPropagation()
    
    const el = e.currentTarget as HTMLElement | null
    const rect = el?.getBoundingClientRect?.()
    onEditField(blockId, fieldPath, rect)
  }
  
  const dataBlockId = editable ? (blockId ?? undefined) : undefined
  const dataEditable = editable ? "true" : undefined

  // Determine which background color to use
  const primaryBgColor = primaryHover && primaryCtaHoverBgColor ? primaryCtaHoverBgColor : primaryCtaBgColor
  const secondaryBgColor = secondaryHover && secondaryCtaHoverBgColor ? secondaryCtaHoverBgColor : secondaryCtaBgColor

  return (
    <AnimatedBlock config={section?.animation}>
      <section
        className="py-16 bg-muted/50"
        style={backgroundColor ? ({ backgroundColor } as React.CSSProperties) : undefined}
        data-block-id={dataBlockId}
        data-editable={dataEditable}
      >
        <div>
          <div
            className={cn(
              "flex flex-col gap-6",
              isCentered && "items-center text-center max-w-2xl mx-auto",
              isSplit && "lg:flex-row lg:items-center lg:justify-between"
            )}
          >
            <div className={cn("flex-1", isSplit && "lg:max-w-xl")}>
              <h2
                className={cn(
                  mergeTypographyClasses(
                    "text-3xl font-bold tracking-tight text-foreground md:text-4xl",
                    (typography as Record<string, any> ?? {})["cta.headline"]
                  ),
                  canInlineEdit && "cursor-pointer"
                )}
                style={{
                  ...headlineShadow,
                  ...(headlineColor ? { color: headlineColor } : {}),
                }}
                data-element-id="headline"
                onClick={canInlineEdit ? (e) => handleInlineEdit(e, FP.headline, "headline") : undefined}
              >
                {headline}
              </h2>
              {(subheadline || canInlineEdit) && (
                <p
                  className={cn(
                    mergeTypographyClasses(
                      "mt-4 text-lg text-muted-foreground",
                      (typography as Record<string, any> ?? {})["cta.subheadline"]
                    ),
                    canInlineEdit && "cursor-pointer"
                  )}
                  style={{
                    ...subheadlineShadow,
                    ...(subheadlineColor ? { color: subheadlineColor } : {}),
                  }}
                  data-element-id="subheadline"
                  onClick={canInlineEdit ? (e) => handleInlineEdit(e, FP.subheadline, "subheadline") : undefined}
                >
                  {subheadline || "(Subheadline)"}
                </p>
              )}
            </div>
            <div
              className={cn(
                "flex flex-wrap gap-4",
                isCentered && "justify-center",
                isSplit && "lg:shrink-0"
              )}
              data-element-id="primaryCta"
              style={primaryCtaShadow as any}
            >
              {/* Primary CTA */}
              {canInlineEdit ? (
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant={primaryPreset.variant}
                    size="lg"
                    className={cn(primaryPreset.className, "gap-2")}
                    style={{
                      color: primaryCtaTextColor || undefined,
                      backgroundColor: primaryBgColor || undefined,
                      borderColor: primaryCtaBorderColor || undefined,
                      borderRadius: primaryCtaBorderRadius || undefined,
                    }}
                    onMouseEnter={() => setPrimaryHover(true)}
                    onMouseLeave={() => setPrimaryHover(false)}
                    onClick={(e) => handleInlineEdit(e, FP.primaryCtaText)}
                  >
                    {primaryCtaText}
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                  <button
                    type="button"
                    className="text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                    onClick={(e) => handleInlineEdit(e, FP.primaryCtaHref)}
                  >
                    Link
                  </button>
                </div>
              ) : (
                <Button
                  asChild
                  variant={primaryPreset.variant}
                  size="lg"
                  className={cn(primaryPreset.className, "gap-2")}
                  style={{
                    color: primaryCtaTextColor || undefined,
                    backgroundColor: primaryBgColor || undefined,
                    borderColor: primaryCtaBorderColor || undefined,
                    borderRadius: primaryCtaBorderRadius || undefined,
                  }}
                  onMouseEnter={() => setPrimaryHover(true)}
                  onMouseLeave={() => setPrimaryHover(false)}
                >
                  <a href={primaryCtaHref}>
                    {primaryCtaText}
                    <ArrowRight className="h-4 w-4" />
                  </a>
                </Button>
              )}
              
              {/* Secondary CTA */}
              {(secondaryCtaText || canInlineEdit) && (
                canInlineEdit ? (
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant={secondaryPreset.variant}
                      size="lg"
                      className={secondaryPreset.className}
                      style={{
                        color: secondaryCtaTextColor || undefined,
                        backgroundColor: secondaryBgColor || undefined,
                        borderColor: secondaryCtaBorderColor || undefined,
                        borderRadius: secondaryCtaBorderRadius || undefined,
                      }}
                      onMouseEnter={() => setSecondaryHover(true)}
                      onMouseLeave={() => setSecondaryHover(false)}
                      onClick={(e) => handleInlineEdit(e, FP.secondaryCtaText)}
                    >
                      {secondaryCtaText || "Secondary CTA"}
                    </Button>
                    <button
                      type="button"
                      className="text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                      onClick={(e) => handleInlineEdit(e, FP.secondaryCtaHref)}
                    >
                      Link
                    </button>
                  </div>
                ) : (
                  secondaryCtaText &&
                  secondaryCtaHref && (
                    <Button
                      asChild
                      variant={secondaryPreset.variant}
                      size="lg"
                      className={secondaryPreset.className}
                      style={{
                        color: secondaryCtaTextColor || undefined,
                        backgroundColor: secondaryBgColor || undefined,
                        borderColor: secondaryCtaBorderColor || undefined,
                        borderRadius: secondaryCtaBorderRadius || undefined,
                      }}
                      onMouseEnter={() => setSecondaryHover(true)}
                      onMouseLeave={() => setSecondaryHover(false)}
                    >
                      <a href={secondaryCtaHref}>{secondaryCtaText}</a>
                    </Button>
                  )
                )
              )}
            </div>
          </div>
        </div>
      </section>
    </AnimatedBlock>
  )
}
