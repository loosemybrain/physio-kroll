Added theme preset migration.
- File: migrations-theme-presets.sql
- Apply this SQL in Supabase after your base migrations.
- Original project files are untouched; this is additive.
