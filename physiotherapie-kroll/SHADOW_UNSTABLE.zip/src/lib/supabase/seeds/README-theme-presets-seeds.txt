Theme presets seed files
- theme-presets-extra.sql: Adds 6 additional presets per brand (12 total). Safe to run multiple times.
Run in Supabase SQL Editor after base schema/migrations.
